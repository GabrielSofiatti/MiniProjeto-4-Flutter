import 'package:flutter/material.dart';
import 'package:mini_projeto04/cliente.dart';
import 'package:mini_projeto04/contato.dart';
import 'package:mini_projeto04/empresa.dart';
import 'package:mini_projeto04/servicos.dart';
import 'HomeScreen.dart';

class RouteGenerator{

  static Route<dynamic> generateRoute(RouteSettings settings){
    switch(settings.name){
      case "/":
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      case "/tela-empresa":
        return MaterialPageRoute(builder: (_) => const EmpresaView());

      case "/tela-servico":
        return MaterialPageRoute(builder: (_) => const servicoView());

      case "/tela-contato":
        return MaterialPageRoute(builder: (_) => const ContatoView());

      case "/tela-cliente":
        return MaterialPageRoute(builder: (_) => const ClienteView());

      default:
        _erroRota();
    }

    throw '';


  }

  static Route<dynamic> _erroRota(){
    return MaterialPageRoute(builder: (_){
      return Scaffold(
        appBar: AppBar(
          title: const Text("Erro Rota"),
        ),
          body: const Text("Tela não encontrada"),
      );
    });
  }

}