import 'package:flutter/material.dart';

class EmpresaView extends StatelessWidget {
  const EmpresaView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Empresa"),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Image.asset('assets/images/detalhe_empresa.png'),
                  const Padding(
                    padding: EdgeInsets.only(left: 10),
                    child: Text(
                      "Sobre a empresa",
                      style: TextStyle(fontSize: 20, color: Colors.deepOrange),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                    height: 16,
                  ),
              const Text("Como assim você se diz egirl? Minha filha ser uma EGIRL é muito mais do que ter o cabelo colorido ou com mecha azul Ser egirl é ser guerreira ser egirl vai muito além de cabelo curto, colorido e ouvir Artic monkeys"),
            ],
          ),
        ),
      ),
    );
  }
}
