import 'package:flutter/material.dart';

class servicoView extends StatelessWidget {
  const servicoView({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Serviços"),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Image.asset('assets/images/detalhe_servico.png'),
                  const Padding(
                    padding: EdgeInsets.only(left: 10),
                    child: Text(
                      "Sobre o serviço",
                      style: TextStyle(fontSize: 20, color: Colors.cyan),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                    height: 16,
                  ),
              const Text("Você não passa de uma garota POSER que acha que ter o cabelo colorido te faz uma egirl... SAIA DAQUI NORMIE!!"),
            ],
          ),
        ),
      ),
    );
  }
}